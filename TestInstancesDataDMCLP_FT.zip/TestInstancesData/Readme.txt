Test instances of DMCLP-FT
T=5
K=3
|J|=150,200,250
|I|=2000,2500,3000

G1
1- arI|I| - Facilities file
	- Coordinate X - Coordinate Y - Period Coverage Radius -> t=1 k=1 - Period Coverage Radius -> t=1 k=2... Period Coverage Radius -> t=5 k=3

2- arD|I|- Demand nodes file
	- Coordinate X - Coordinate Y - Demand t=1... Demand t=5

G2
1- DatosInstalaciones|J| - Facilities file
	- Coordinate X - Coordinate Y - Period Coverage Radius -> t=1 k=1 - Period Coverage Radius -> t=1 k=2... Period Coverage Radius -> t=5 k=3

2- DatosInstancia|I|- Demand nodes file
	- Coordinate X - Coordinate Y - Demand t=1... Demand t=5